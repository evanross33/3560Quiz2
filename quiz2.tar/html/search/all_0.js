var searchData=
[
  ['add',['add',['../classCollege.html#a67fd1d8970b46b24ce2e0dd72598a22f',1,'College']]]
];
