var searchData=
[
  ['operator_3d',['operator=',['../classCollege.html#af2194c9b37f80d13dc3fdba6784b18e8',1,'College']]]
];
