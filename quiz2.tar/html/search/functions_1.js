var searchData=
[
  ['get_5fnumber_5fgrade',['get_number_grade',['../classcourse.html#aad43a6b7ce264bd4038472fc3e40cf16',1,'course']]]
];
